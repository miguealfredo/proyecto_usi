from django.http import HttpResponse
from django.template import Template, Context

def formulario(request):

    doc_externo=open("/var/www/html/django/proyecto_USI/proyecto_usi/proyecto_usi/plantillas/formulario.html")

    ptl = Template(doc_externo.read())

    doc_externo.close()

    ctx = Context()

    documento = ptl.render(ctx)

    return HttpResponse(documento)

def visualizar_datos(request):
    mensaje="Datos del usuario nombre:%s  direccion:%s  telefono:%s" % (request.GET["nombre"], request.GET["direccion"], request.GET["telefono"])
    return HttpResponse(mensaje)